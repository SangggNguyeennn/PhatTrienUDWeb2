package jp.ivs.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	@RequestMapping("/index")
	public String trangchu() {
		return "index";
	}
	@RequestMapping("/about")
	public String thongTin() {
		return "about";
	}

}
