package jp.ivs.controller;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class BMIController extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("BMI.jsp");
        dispatcher.forward(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        double weight = Double.parseDouble(request.getParameter("weight"));
        double height = Double.parseDouble(request.getParameter("height"));
        double bmi = weight / (height * height);
        String bmiMessage = "";

        if(bmi<18.5) {
        	bmiMessage = "<p>Gay</p>";
		}
		if(bmi>18.5 && bmi<24.9) {
			bmiMessage = "<p>Binh Thuong</p>";
		}
		if(bmi>25 && bmi<29.9) {
			bmiMessage = "<p>Hoi Beo</p>";
		}
		if(bmi>30 && bmi<34.9) {
			bmiMessage = "<p>Beo Phi Cap Do 1</p>";
		}
		if(bmi>35 && bmi<39.9) {
			bmiMessage = "<p>Beo Phi Cap Do 2</p>";
		}
		if(bmi>40) {
			bmiMessage = "<p>Beo Phi Cap Do 3</p>";
		}

        request.setAttribute("bmi", bmi);
        request.setAttribute("bmiMessage", bmiMessage);
        RequestDispatcher dispatcher = request.getRequestDispatcher("BMI.jsp");
        dispatcher.forward(request, response);
    }
}
